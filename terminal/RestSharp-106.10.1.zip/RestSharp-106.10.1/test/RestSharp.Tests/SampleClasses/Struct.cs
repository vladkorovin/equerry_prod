﻿namespace RestSharp.Tests.SampleClasses
{
    public struct SimpleStruct
    {
        public string One { get; set; }

        public string Two { get; set; }

        public int Three { get; set; }
    }
}