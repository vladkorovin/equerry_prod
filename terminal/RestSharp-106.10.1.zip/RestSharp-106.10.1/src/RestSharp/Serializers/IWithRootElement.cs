namespace RestSharp.Serialization
{
    public interface IWithRootElement
    {
        string RootElement { get; set; }
    }
}